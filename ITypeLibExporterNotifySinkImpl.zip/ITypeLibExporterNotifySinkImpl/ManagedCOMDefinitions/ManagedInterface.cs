﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.InteropServices;

namespace ManagedCOMDefinitions
{
    [ComVisible(true)]
    [Guid("F290B613-B5B3-4B80-BB98-88F5985AB63C")]
    [InterfaceType(ComInterfaceType.InterfaceIsDual)]
    public interface IManagedInterface
    {
        void TestMethod01();
    }

}
