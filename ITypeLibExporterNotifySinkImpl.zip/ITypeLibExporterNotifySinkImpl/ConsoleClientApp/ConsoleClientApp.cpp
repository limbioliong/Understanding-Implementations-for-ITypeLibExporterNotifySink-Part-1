// ConsoleClientApp.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#import "..\ManagedImplementation\bin\Debug\ManagedCOMDefinitions.tlb" raw_interfaces_only no_implementation 
using namespace ManagedCOMDefinitions;
#import "..\ManagedImplementation\bin\Debug\ManagedImplementation.tlb" raw_interfaces_only no_implementation 
using namespace ManagedImplementation;

void DoTest()
{
	IManagedInterfacePtr spIManagedInterface = NULL;

	spIManagedInterface.CreateInstance(__uuidof(ManagedImpl01));

	if (spIManagedInterface)
	{
		spIManagedInterface->TestMethod01();
	}
}

int main()
{
	::CoInitialize(NULL);

	DoTest();

	::CoUninitialize();

	return 0;
}

