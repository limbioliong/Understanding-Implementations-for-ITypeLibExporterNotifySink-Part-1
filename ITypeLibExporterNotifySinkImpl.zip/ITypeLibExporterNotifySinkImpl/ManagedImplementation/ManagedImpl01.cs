﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.InteropServices;
using ManagedCOMDefinitions;

namespace ManagedImplementation
{
    [ComVisible(true)]
    [Guid("15EE143E-7DAD-4C84-A417-AAB2495D3302")]
    [ClassInterface(ClassInterfaceType.None)]
    [ProgId("ManagedImplementation.ManagedImpl01")]
    public class ManagedImpl01 : IManagedInterface
    {
        public ManagedImpl01()
        {
        }

        #region IManagedInterface implementation.
        public void TestMethod01()
        {
            Console.WriteLine("ManagedImplementation.ManagedImpl01 IManagedInterface.TestMethod01()");
        }
        #endregion IManagedInterface implementation.
    }
}
